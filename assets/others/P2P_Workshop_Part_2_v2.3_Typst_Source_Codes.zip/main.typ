#import "@preview/diatypst:0.9.3": *

#let usyd-ochre = rgb("#e64626")
#let usyd-sandstone = rgb("#fcede2")
#let usyd-black = rgb("#000000")
#let usyd-light-grey = rgb("#f1f1f1")
#let usyd-charcoal = rgb("#424242")
#let usyd-heritage-rose = rgb("#daa8a2")
#let usyd-jacaranda = rgb("#8f9ec9")
#let usyd-navy = rgb("#1a355e")
#let usyd-eucalypt = rgb("#71a499")

// Keep the generated contents slide readable: section headings only.
#set outline(depth: 1)

#show: slides.with(
  title: "COMP2017 26S1 Passway to Pass", // Required
  subtitle: "Workshop Part 2",
  date: "13:00-15:00, 16 July 2026",
  authors: "Hao Ren",
  // Optional Style Options
  title-color: usyd-ochre,
  ratio: 16/9, // aspect ratio of the slides, any valid number
  layout: "medium", // one of "small", "medium", "large"
  toc: true,
  count: "number", // one of "dot", "dot-section", "number", or none
  footer: true,
  theme: "normal"
  // footer-title: "Custom Title",
  // footer-subtitle: "Custom Subtitle",
  // theme: "full", // one of "normal", "full"
  // ... see the docs for more options
)

#set align(horizon)

#set text(size: 12pt, fill: usyd-black)
#set par(leading: 0.52em)

#let key-box(title, body, fill: usyd-sandstone) = block(
  width: 100%,
  fill: fill,
  stroke: (left: 3pt + usyd-ochre),
  radius: 4pt,
  inset: 8pt,
  [#strong(title) #h(0.35em) #body],
)

#let rule(body) = key-box([Note:], body)

#let node(body, fill: usyd-sandstone, stroke: usyd-ochre) = rect(
  width: 100%,
  fill: fill,
  stroke: 1pt + stroke,
  radius: 4pt,
  inset: 7pt,
  align(center + horizon, body),
)

#let question(body) = block(
  width: 100%,
  fill: usyd-sandstone,
  stroke: 1.2pt + usyd-ochre,
  radius: 5pt,
  inset: 12pt,
  align(center, text(size: 21pt, weight: "bold", fill: usyd-ochre, body)),
)

#let code-text(body) = text(size: 12pt, body)
#let tiny(body) = text(size: 11.5pt, body)
#let arrow = text(size: 20pt, weight: "bold", fill: usyd-ochre)[->]
#let bad(body) = text(fill: usyd-navy, weight: "bold", body)
#let good(body) = text(fill: usyd-eucalypt, weight: "bold", body)

// -----------------------------------------------------------------------------

== Preface

These slides may be *updated dynamically* over the coming days, so please always check this page for the latest version.

Additionally, please note that our workshop does not cover all of the semester's content. For more detailed explanations, you can visit *#link("https://github.com/ninn-kou/COMP2017-Tutorials")*.

#v(12pt)

#key-box([Updates],
[\ 

  16 July 2026: Version 1.0 - The materials are uploaded.\ 
  18 July 2026: Version 2.0 - Two practice exercises are available via the P2P page on Ed Lessons.\ 
  18 July 2026: Version 2.1 - Some formatting issues have been corrected.\ 
  18 July 2026: Version 2.2 - Attach a code snippet in Processes part.\ 
  18 July 2026: Version 2.3 - Add more illustrations about pipelines.\ 
])

#align(right + bottom)[
  _Slides Version: 2.3_
]

= Process Memory and Lifecycle

== Process and Its Memory Layout

#grid(
  columns: (0.5fr, 0.5fr),
  gutter: 16pt,
  [
    #figure(
      image("img/memory_layout.png")
    )
  ],
  [
    #figure(
      image("img/3_03_PCB.jpg")
    )
    A process is the running instance of a program. A process has its own virtual address space and its own process control block (PCB).
  ]
)

```c
#include <stdio.h>
#include <stdlib.h>

int global_init = 123;                                   // usually in .data
int global_bss;                                          // usually in .bss
static int static_init = 7;                              // usually in .data
static int static_bss;                                   // usually in .bss

int main(int argc, char *argv[]) {
    int local = 5;                                       // usually on the stack
    int *heap = malloc(sizeof *heap);                    // points into the heap

    free(heap);
    return 0;
}
```


// SPEAKER [03:00]
// DRAW: Recreate this as two territories: user-space memory and kernel state.
// ASK: Is the file descriptor table just another array in the heap?
// EXPECT: No. It is kernel-maintained process state.
== Process Memory and Kernel Descriptor State

#grid(
  columns: (1.1fr, 0.9fr),
  gutter: 16pt,
  [
    #align(center)[*Virtual Address Space*]
    #stack(spacing: 3pt,
      node([stack: frames and local variables], fill: usyd-light-grey),
      node([heap: dynamic allocations]),
      node([data / BSS: globals and statics], fill: usyd-light-grey),
      node([code / text: instructions]),
    )
  ],
  [
    #align(center)[*Kernel-Managed Process State*]
    #stack(spacing: 5pt,
      node([PID and lifecycle state], fill: white),
      node([file descriptor table], fill: white),
      node([signal dispositions], fill: white),
      node([open-file and pipe references], fill: white),
    )
  ],
)

#v(0.25cm)
#rule([Ordinary locals, globals, and heap objects belong to one process image.])

// SPEAKER [04:00]
// ASK: Let students predict the parent's final value before showing the child box.
// TRACE: Mention copy-on-write only as an implementation detail.
// COMMON ERROR: "Both processes began with 0, so they share the variable."
== Reveal: `fork()` Copies Values, Not One Shared Object

#grid(
  columns: (1fr, auto, 1fr),
  gutter: 12pt,
  align: horizon,
  node([*Before `fork()`*\ parent `var = 42`], fill: usyd-light-grey),
  arrow,
  [
    #stack(spacing: 8pt,
      node([*Parent Image*\ `var = 42`]),
      node([*Child Image*\ changes its copy to `66`]),
    )
  ],
)

#v(0.4cm)
#key-box([Note:], [
  The parent's ordinary `partial` remains *0*. The child needs an IPC path to return `66`.
])

// SPEAKER [03:00]
// TRACE: Say the return value aloud on each branch.
// ASK: Which branch exists when fork returns -1?
// COMMON ERROR: Writing only child/else branches and ignoring creation failure.
== One `fork()` Call Creates Two Continuing Paths

#grid(
  columns: (1.3fr, 0.7fr),
  gutter: 14pt,
  [
    #table(
      columns: (0.7fr, 1.3fr),
      [`fork()` Returns], [Meaning],
      [`-1`], [Creation failed; no child],
      [`0`], [This is the child path],
      [`> 0`], [This is the parent; value is child PID],
    )
  ],
  code-text[
```c
pid_t pid = fork();
if (pid < 0) {
    perror("fork");
} else if (pid == 0) {
    /* child path */
} else {
    /* parent path */
}
```
  ],
)

#v(0.2cm)
#rule([Source-code order does not guarantee parent/child scheduling order.])
#question([
  How many processes do you have if you run the following code block?
  ```c
  fork();
  fork();
  fork();
  ```
])

== `exec*()` Family

You don't need to remember them word by word, just make sure you know the difference between them, and could use anyone of them in the correct senecio.

```c
int execvp (const char *file, char *const argv[]);
int execv(const char *path, char *const argv[]);
int execlp(const char *file, const char *arg,... (char  *) NULL);
int execl(const char *path, const char *arg,... (char  *) NULL);
int execvpe(const char *file, char *const argv[],char *const envp[]);
int execle(const char *path, const char *arg, ..., (char *) NULL, char * const envp[] );
```

== Example Usage of `execl()`

```c
#include <stdio.h>
#include <unistd.h>

int main(void) {
    puts("about to launch sort");

    if (execl("/usr/bin/sort", "sort", "forkdemo.c", NULL) == -1) {
        perror("exec failed");
        return 1;
    }

    puts("finished sort");
    return 0;
}
```

// SPEAKER [03:00]
// ASK: Hold the answer. Which lines execute if execl succeeds?
// EXPECT: None after the call in the old image.
// TRANSITION: exec changes what a process runs; it does not make another process.
== What Executes After a Successful `exec()`?

```c
if (pid == 0) {
    execl("/bin/echo", "echo",
          "ready", (char *)NULL);
    perror("execl");
    _exit(127);
}
```

#grid(
  columns: (1fr, 1fr),
  gutter: 16pt,
  [
    #question([On success, does `perror()` run?])
    #align(center)[No. Explain the reason.]
  ],
  [
    #v(0.35cm)
    #align(center)[*Same PID, new program image.*]
  ],
)

== `wait()` and `waitpid()`

`wait()` and `waitpid()` do not wait for "another process" in general. They wait for a child of the calling process.

```c
pid_t pid = fork();

if (pid == 0) {
    printf("HC: hello from child\n");
} else if (pid > 0) {
    printf("HP: hello from parent\n");
    wait(NULL); // Equiv to waitpid(pid, NULL, 0);
    printf("CT: child has terminated\n");
}
```

// SPEAKER [03:00]
// REVEAL: A successful exec never returns to the old image.
// ASK: Is an exit status the same thing as an arbitrary result record?
// EXPECT: No. Status classifies termination; IPC carries normal result data.
== `exec()` Replaces; `waitpid()` Observes

#align(center)[*After `fork()`, the two lanes continue independently.*]
#v(0.1cm)
#grid(
  columns: (1fr, 1fr),
  gutter: 14pt,
  [
    #node([*Child Lane*\ close/redirect FDs -> `exec*()` -> new program])
  ],
  [
    #node([*Parent Lane*\ `wait()` / `waitpid()` -> inspect status], fill: usyd-light-grey)
  ],
)

#v(0.35cm)
#grid(
  columns: (1fr, 1fr),
  gutter: 14pt,
  key-box([Successful `exec*()`], [Replaces the process image and does not return. Open FDs normally survive unless marked close-on-exec.]),
  key-box([Child selection], [`wait()` selects an eligible child; `waitpid(pid, ...)` selects the requested child.], fill: usyd-light-grey),
)

== W8 Tutorial B Exercise: Bash Simulator

Import header files and start the main loop.

```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define BUFFER_SIZE 1024
#define MAX_ARGS 64

int main(void) {
    char line[BUFFER_SIZE];
    while (1) {
        ...
```
#pagebreak()

Handle the arguments and convert the input into tokens.
```c
        ...
        printf("mini$ ");
        fflush(stdout);
        
        if (fgets(line, sizeof line, stdin) == NULL) {
            printf("\n");
            break;
        }
        
        line[strcspn(line, "\n")] = '\0';
        
        if (line[0] == '\0') continue;
        
        char *argv[MAX_ARGS];
        int argc = 0;
        char *token = strtok(line, " \t");
        
        while (token != NULL && argc < MAX_ARGS - 1) {
            argv[argc++] = token;
            token = strtok(NULL, " \t");
        }
        
        argv[argc] = NULL;
        if (argc == 0) continue;
        if (strcmp(argv[0], "exit") == 0) break;
        ...

```
#pagebreak()

Fork the process, replace the program in the child process, and pass arguments.
```c
        ...
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork failed");
            continue;
        }
        if (pid == 0) {
            execvp(argv[0], argv);
            perror("execvp failed");
            _exit(127);
        } else {
            if (waitpid(pid, NULL, 0) == -1) {
                perror("waitpid failed");
            }
        }
    }
    return 0;
}
```

For detailed explanations, please visit #link("https://github.com/ninn-kou/COMP2017-Tutorials/blob/main/Week%208/Week_8_Tutorial_B.md#b6-exercise-bash-simulator")[the corresponding chapter in my tutorial notes].


= IPC and Process Workers

// SPEAKER [03:00]
// ASK: Is descriptor 4 the pipe itself, or a process-local handle to an endpoint?
// DRAW: Follow each arrow from integer entry to kernel object.
== A File Descriptor Is a Handle, Not the Data

#figure(
  image("img/File_table_and_inode_table.svg")
)

#pagebreak()

== `STDIN`, `STDOUT`, and `STDERR`

#figure(
  image("img/Pipeline.svg")
)

#grid(
  columns: (1fr, auto, 1fr),
  gutter: 12pt,
  align: horizon,
  [
    #table(
      columns: (0.35fr, 1fr),
      [FD], [Process-Local Meaning],
      [`0`], [standard input],
      [`1`], [standard output],
      [`2`], [standard error],
      [`3`], [pipe read end],
      [`4`], [pipe write end],
    )
  ],
  arrow,
  [
    #stack(spacing: 10pt,
      node([terminal / file open description], fill: usyd-light-grey),
      node([kernel pipe object\ read endpoint + write endpoint]),
    )
  ],
)

#v(0.25cm)
#rule([Example FDs only: `pipe()` returns the lowest available numbers. Each integer indexes a process table entry that refers to a kernel object.])

== `pipe()`

#grid(
  columns: (1fr, 1fr),
  gutter: 14pt,
  figure(
    image("img/1-27.jpg")
  ),
  figure(
    image("img/pipe.svg")
  ),
)



// SPEAKER [03:00]
// ASK: Which endpoint should a one-way child-to-parent design keep in each process?
// TRACE: Closing a copied entry in one process does not close the other copy.
== Forked Processes Reference the Same Pipe

#figure(
  image("img/pipe3.png")
)


#grid(
  columns: (1fr, auto, 0.85fr, auto, 1fr),
  gutter: 7pt,
  align: horizon,
  node([*Parent FD Table*\ `fd[0]` read\ `fd[1]` write], fill: usyd-light-grey),
  text(size: 18pt, weight: "bold", fill: usyd-ochre)[↔],
  node([*Kernel Pipe*\ byte stream]),
  text(size: 18pt, weight: "bold", fill: usyd-ochre)[↔],
  node([*Child FD Table*\ `fd[0]` read\ `fd[1]` write], fill: usyd-light-grey),
)

#v(0.35cm)
#grid(
  columns: (1fr, 1fr),
  gutter: 14pt,
  key-box([Parent keeps], [`fd[0]` for reading; closes its inherited `fd[1]`.]),
  key-box([Child keeps], [`fd[1]` for writing; closes its inherited `fd[0]`.], fill: usyd-light-grey),
)

#v(0.2cm)
#align(center)[#strong([Data direction: child `fd[1]` -> kernel pipe -> parent `fd[0]`.])]

// SPEAKER [03:00]
// ASK: Parent still owns an unused write end. Will read report EOF after child exits?
// REVEAL: No. Every write reference must be closed.
// COMMON ERROR: Treating a pipe as a record queue with message boundaries.
== Reveal: Pipe EOF and Complete Transfer

#grid(
  columns: (1fr, 1fr),
  gutter: 14pt,
  [
    #question([Child closed its writer. Parent still holds a writer. EOF?])
    #v(0.25cm)
    #align(center)[#bad([No, one write-end reference remains open.])]
  ],
  [
    #key-box([A pipe is a byte stream:], [
      One `write()` does not promise one complete matching `read()`.

      Retry partial transfers and `EINTR`; treat early EOF as incomplete data.
    ])
  ],
)

#v(0.25cm)
#rule([Close every unused endpoint, then use complete-transfer helpers for fixed records.])

== Example Usage of Processes and Pipelines

```c
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(void) {
    int pipefd[2];
    if (pipe(pipefd) == -1) {
        perror("pipe");
        return 1;
    }
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        return 1;
    }
    ...
```
#pagebreak()
```c
    ...
    // Child: redirect stdout to the pipe.
    if (pid == 0) {
        // Child: redirect stdout to the pipe.
        close(pipefd[0]); // child does not read
        if (dup2(pipefd[1], STDOUT_FILENO) == -1) {
            perror("dup2");
            return 1;
        }
        // fd 1 now refers to the pipe, so this is no longer needed
        close(pipefd[1]);
        printf("hello from child\n");
        fflush(stdout);
        return 0;
    }
    ...
```
#pagebreak()
```c
    ...
    // Parent: read from the pipe.
    close(pipefd[1]); // parent does not write
    char buffer[256];
    ssize_t nread = read(pipefd[0], buffer, sizeof(buffer) - 1);
    if (nread == -1) {
        perror("read");
        close(pipefd[0]);
        waitpid(pid, NULL, 0);
        return 1;
    }
    buffer[nread] = '\0';
    printf("parent received: %s", buffer);
    close(pipefd[0]);
    waitpid(pid, NULL, 0);
    return 0;
}
```

// SPEAKER [03:00]
// ASK: Fill the five labels before discussing system calls.
// PROMPT: Four workers sum 1 through 11. Who owns tasks, routes, completion, blocking, combination?
== Design the Process Solution Before System Calls

#grid(
  columns: (1fr, 1fr, 1fr, 1fr),
  gutter: 7pt,
  node([Worker 0\ `[0, 3)`\ partial `6`], fill: white),
  node([Worker 1\ `[3, 6)`\ partial `15`], fill: white),
  node([Worker 2\ `[6, 9)`\ partial `24`], fill: white),
  node([Worker 3\ `[9, 11)`\ partial `21`], fill: white),
)

#v(0.4cm)
#question([How will each partial reach the parent, and how will the parent know it is final?])

#v(0.25cm)
#align(center)[Half-open ranges: adjacent boundaries, no gaps, no overlap, final end `11`.]

// SPEAKER [03:00]
// REVEAL: Point out the two different arrows into the parent.
// ASK: Why does each child compute into a local value first?
// EXPECT: Private ownership and one small transfer.
== The Process Result Path Has Six Explicit Stages

#grid(
  columns: (1fr, auto, 1fr, auto, 1fr),
  gutter: 7pt,
  align: horizon,
  node([1. one `pipe()`\ per worker]), arrow,
  node([2. `fork()`; record\ every created PID]), arrow,
  node([3. child computes\ private partial]),
)

#v(0.3cm)
#grid(
  columns: (1fr, auto, 1fr, auto, 1fr),
  gutter: 7pt,
  align: horizon,
  node([4. child writes; parent\ reads complete record], fill: usyd-light-grey), arrow,
  node([5. parent `waitpid()`\ reaps and validates], fill: usyd-light-grey), arrow,
  node([6. combine only\ complete result set], fill: usyd-light-grey),
)

#v(0.28cm)
#rule([Transport and completion are separate arrows; a strong answer names both.])

// SPEAKER [03:00]
// TRACE: Grey out every inherited descriptor except this child's writer.
// ASK: Why use _exit in the child failure path after fork?
// COMMON ERROR: Letting a child continue into the parent's creation loop.
== Child Path: One Range, One Result Channel

#grid(
  columns: (1.15fr, 0.85fr),
  gutter: 14pt,
  code-text[
```c
if (pid == 0) {
    close(result_fd[i][0]);
    close_unrelated_fds(result_fd, i);

    int64_t partial =
        sum_range(begin, end);
    int out = result_fd[i][1];
    if (write_full(out, &partial,
                   sizeof partial) < 0)
        _exit(1);
    close(out);
    _exit(0);
}
```
  ],
  [
    #key-box([Child Obligations], [
      - keep one range;
      - keep one write endpoint;
      - compute privately;
      - transfer exactly one record;
      - close and terminate.
    ])
  ],
)

// SPEAKER [03:00]
// TRACE: Read one complete record, reap that exact PID, validate, then add.
// NOTE: read_result loops for a complete fixed-size record; waitpid_nointr retries
// waitpid() after EINTR; child_exited_ok checks the PID, WIFEXITED, and zero exit
// status. These are teaching helpers, not additional POSIX APIs.
// ASK: What happens if the third fork fails after two children exist?
// EXPECT: Clean up and reap only the successfully created set; reject missing results.
== The Parent Collects, Reaps, Validates, Then Combines

#grid(
  columns: (0.9fr, 1.1fr),
  gutter: 14pt,
  key-box([Collect Every Created Result], code-text[
```c
for(size_t i=0; i < created; i++) {
    data_ok[i] = read_result(fd[i], &partial[i]);
    close(fd[i]);
}
```
  ]),
  key-box([Reap Every Created Child], code-text[
```c
for(size_t i = 0; i < created; i++) {
    int status;
    pid_t got = waitpid_nointr(child[i], &status);
    child_ok[i] = child_exited_ok(got, child[i], status);
}
```
  ], fill: usyd-light-grey),
)

#v(0.15cm)
#tiny[#rule([Reap every created child. Publish only if all intended workers, records, and statuses are valid; otherwise recover or reject.])]

// SPEAKER [02:00]
// ASK: Do not reveal yet. Draw what each side needs to make progress.
// NOTE: This is a liveness question, not merely a performance question.
== Can the Parent Wait Before Draining a Large Pipe?

#grid(
  columns: (1fr, 1fr),
  gutter: 16pt,
  node([*Parent*\ `waitpid(child, ...)`\ waits for termination], fill: usyd-light-grey),
  node([*Child*\ `write(large_result)`\ may wait for pipe space]),
)

#v(0.5cm)
#question([If the pipe becomes full, who can perform the next enabling action?])

// SPEAKER [02:00]
// REVEAL: Follow the cycle clockwise. Neither participant can reach its enabling step.
// TRANSITION: Several active streams motivate readiness observation.
== Wait-Before-Read Can Create a Progress Cycle

#grid(
  columns: (1fr, auto, 1fr),
  gutter: 8pt,
  align: horizon,
  node([*Parent blocked*\ inside `waitpid()`], fill: usyd-light-grey),
  text(size: 16pt, weight: "bold", fill: usyd-ochre)[needs child exit →],
  node([*Child cannot exit*\ blocked in `write()`]),
)

#v(0.24cm)
#grid(
  columns: (1fr, auto, 1fr),
  gutter: 8pt,
  align: horizon,
  node([*Parent cannot read*\ while waiting], fill: usyd-light-grey),
  text(size: 16pt, weight: "bold", fill: usyd-ochre)[← needs pipe space],
  node([*Child remains blocked*\ pipe is full]),
)

#v(0.25cm)
#rule([Drain output before a wait that could strand the producer. With several streams, observe readiness and then read.])

// SPEAKER [03:00]
// RAPID FIRE: event only, byte stream, many FDs, large region, child completion.
// EMPHASISE: A readiness API reports a condition; it does not transfer bytes.
== Choose IPC by What Must Cross the Boundary

#table(
  columns: (0.9fr, 1.05fr, 1.05fr),
  inset: 5pt,
  [Need], [Mechanism], [Defining Semantic],
  [Small event notification], [`sigaction()` + signal], [Notify; keep handler minimal],
  [One-way byte stream], [`pipe()`], [Kernel transfers bytes],
  [Several active FDs], [`select()` / `poll()` / `epoll`], [Report readiness; then call I/O],
  [Large addressable region], [`mmap(..., MAP_SHARED, ...)`], [Shared visibility; add synchronization],
  [Child state and reaping], [`waitpid()`], [Lifecycle, not arbitrary data],
)

#v(0.18cm)
#align(center)[#strong([Choose by the information crossing the boundary, not by a familiar API name.])]

// SPEAKER [03:00]
// ASK: What does readable not guarantee? Expected: a complete application record.
// ASK: Can SIGCHLD replace result transport or reaping? Expected: neither.
// ASK: Does MAP_SHARED make updates race-free? Expected: no.
== Signals 

#grid(
  columns: (1fr, 1fr),
  gutter: 16pt,
  key-box([Signal], [
    
    `signal()` is legacy shorthand. Prefer `sigaction()` with explicit mask and flags.
    
    Handler sets a `volatile sig_atomic_t` flag; ordinary control flow does work.
  ]),
  [
    ```c
    #include <signal.h>
    
    static volatile sig_atomic_t got_sigint = 0;
    
    static void handle_sigint(int signum) {
        (void)signum;
        got_sigint = 1;
    }
    ```
  ]
)




The handler receives the signal number. In this example, the handler only sets a flag. That is a good habit because signal handlers should stay small.

```c
struct sigaction sa;

sa.sa_handler = handle_sigint;
sigemptyset(&sa.sa_mask);
sa.sa_flags = SA_RESTART;

if (sigaction(SIGINT, &sa, NULL) == -1) {
    perror("sigaction");
}
```

- when `SIGINT` arrives, call `handle_sigint`
- while the `handler` is running, block only the default extra signals from `sa_mask`
- use `SA_RESTART` behaviour where possible

== Readiness, and Shared Mappings
  #key-box([Readiness], [
  
    `select`: rebuilt FD sets.

    `poll`: `pollfd` array.

    `epoll`: persistent Linux interest set.
  ], fill: usyd-light-grey)
  
  #key-box([Shared Mapping], [
  
    Create anonymous `MAP_SHARED` before `fork()`.

    `malloc()` / `MAP_PRIVATE` stay private. Add synchronization.
  ])


#v(0.3cm)
#align(center)[#strong([Every result path still needs framing, validation, and cleanup.])]

= Threads and Worker-Combiner

== Use Threads to Run Small Tasks in Parallel

#grid(
  columns: (1fr, 1fr),
  gutter: 16pt,
  figure(
    image("img/thread_1.png"),
  ),
  figure(
    image("img/thread_2.png"),
  )
)

== Prototype: Create Threads in C

```c
int pthread_create(pthread_t *thread,
                   const pthread_attr_t *attr,
                   void *(*start_routine)(void *),
                   void *arg);

// thread          where the new thread ID is stored
// attr            thread attributes; usually NULL for defaults
// start_routine   function the new thread will run
// arg             argument passed to that function
```

// SPEAKER [03:00]
// ASK: Four threads in one process: how many heaps and how many stacks?
// EXPECT: One shared heap, four thread stacks.
== Threads Share the Address Space, Not Execution State

#grid(
  columns: (1.1fr, 0.9fr),
  gutter: 14pt,
  [
    #node([*One process boundary*\ shared code, globals, heap, and file descriptors])
    #v(0.25cm)
    #grid(
      columns: (1fr, 1fr, 1fr),
      gutter: 5pt,
      node([T0\ stack], fill: white),
      node([T1\ stack], fill: white),
      node([T2\ stack], fill: white),
    )
  ],
  [
    #table(
      columns: (0.8fr, 1.2fr),
      [Shared], [Separate per thread],
      [globals], [stack],
      [heap], [registers],
      [FD table], [program counter],
    )
  ],
)

#v(0.25cm)
#rule([Shared visibility removes IPC copies; it does not remove race conditions.])

// SPEAKER [03:00]
// TRACE: Keep the same four ranges and arithmetic as the process design.
// ASK: Which state has exactly one writer?
== Worker-Combiner Makes Ownership Visible

#grid(
  columns: (1fr, auto, 1fr, auto, 1fr),
  gutter: 7pt,
  align: horizon,
  node([Partition\ four stable task records]), arrow,
  node([Create all\ workers compute privately]), arrow,
  node([Join all\ main combines `53`]),
)

#v(0.35cm)
#grid(
  columns: (1fr, 1fr),
  gutter: 14pt,
  key-box([Coverage invariant], [Every input index is in exactly one half-open range.]),
  key-box([Ownership invariant], [Each result slot has one worker writer; main reads after join.], fill: usyd-light-grey),
)

#v(0.25cm)
#rule([Prefer private partials plus a combiner over locking every update.])

// SPEAKER [03:00]
// ASK: What address does every call receive? What values might workers observe later?
// COMMON ERROR: Assuming creation immediately schedules the new thread.
== Why is Passing `&i` From the Loop Unsafe?

```c
for (size_t i = 0; i < N; i++) {
    pthread_create(&thread[i], NULL, worker, &i);  // wrong
}
```

#question([How many distinct addresses did the workers receive?])
#v(0.3cm)
#align(center)[loop: `i = 0 -> 1 -> 2 -> 3 -> 4`\ worker may first run here]

// SPEAKER [03:00]
// REVEAL: Stable array elements provide distinct addresses and sufficient lifetime.
// ASK: Why does task->result not need a mutex in this design?
// EXPECT: One writer; main reads only after a successful join.
== Stable Task Records Give Every Worker One Result Slot

#grid(
  columns: (0.7fr, 1.3fr),
  gutter: 14pt,
  code-text[
```c
struct task {
    const int *values;
    size_t begin, end;
    int64_t result;
};
```
  ],
  code-text[
```c
static void *worker(void *arg) {
    struct task *t = arg;
    int64_t local = 0;
    for (size_t i = t->begin; i < t->end; i++)
        local += t->values[i];
    t->result = local;   // one writer
    return NULL;
}
```
  ],
)

#v(0.18cm)
#rule([Stable lifetime + distinct record address + one writer + join-before-read.])

// SPEAKER [03:00]
// ASK: Vote A or B. Then sketch the worker lanes rather than arguing from syntax.
== Which Loop Shape Preserves Parallel Overlap?

#grid(
  columns: (1fr, 1fr),
  gutter: 16pt,
  key-box([A: immediate join], [
```c
for each i:
    create(i)
    join(i)
```
  ], fill: usyd-light-grey),
  key-box([B: two phases], [
```c
for each i: create(i)
for each i: join(i)
```
  ]),
)

#v(0.45cm)
#question([Which shape lets workers overlap in time?])

// SPEAKER [03:00]
// REVEAL: B. Joining thread 0 first does not force it to finish first.
// FAILURE: If create 2 fails, join the successfully created prefix/set and reject
// the incomplete result unless the missing ranges are explicitly recovered.
// TRANSITION: Same algorithm, different result and completion plumbing.
== Create the Set, Join the Created Set, Then Combine

#grid(
  columns: (1fr, 1fr),
  gutter: 14pt,
  [
    #align(center)[*Execution lanes*]
    #stack(spacing: 5pt,
      node([main: create 0 | create 1 | create 2], fill: usyd-light-grey),
      node([T0: ========= partial 9]),
      node([T1: ========= partial 22], fill: white),
      node([T2: ========= partial 22]),
      node([main: join created set -> validate coverage -> combine `53`], fill: usyd-light-grey),
    )
  ],
  [
    #table(
      columns: (0.8fr, 1fr, 1fr),
      [Job], [Processes], [Threads],
      [Result], [pipe/shared mapping], [shared task slot],
      [Complete], [`waitpid()`], [`pthread_join()`],
      [Cleanup], [close + reap], [join created set],
    )
  ],
)

== Simple Example of Threads in C

For more instructions, you could visit my notes on #link("https://github.com/ninn-kou/COMP2017-Tutorials/blob/main/Week%2010/Week_10_Tutorial_B.md").

```c
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void *worker(void *arg) {
    (void)arg;
    printf("hello from worker thread\n");
    return NULL;
}
```

#pagebreak()

```c
int main(void) {
    pthread_t thread;
    int err = pthread_create(&thread, NULL, worker, NULL);
    if (err != 0) {
        fprintf(stderr, "pthread_create: %s\n", strerror(err));
        return EXIT_FAILURE;
    }
    printf("hello from main thread\n");
    err = pthread_join(thread, NULL);
    if (err != 0) {
        fprintf(stderr, "pthread_join: %s\n", strerror(err));
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
```

= Race Conditions and Mutexes

// SPEAKER [04:00]
// ASK: Expand ++ into read, compute, write. Let students build the bad interleaving.
// DO NOT REVEAL the final value until the next slide.
== Can Two Increments Succeed but Increase Only Once?

#grid(
  columns: (0.75fr, 1.25fr),
  gutter: 16pt,
  [
    #node([Initial shared value\ `total = 7`], fill: usyd-light-grey)
    #v(0.45cm)
    #question([Two threads execute `total++`. Must the result be 9?])
  ],
  [
    #table(
      columns: (0.35fr, 1fr, 1fr),
      [Step], [Thread A], [Thread B],
      [1], [read ?], [],
      [2], [], [read ?],
      [3], [compute ?], [],
      [4], [], [compute ?],
      [5], [write ?], [],
      [6], [], [write ?],
    )
  ],
)

// SPEAKER [04:00]
// REVEAL: Both reads can observe 7. Emphasise that successful test runs prove nothing.
// ASK: Where does the invariant become vulnerable?
== A Legal Interleaving can Lose One Update

#table(
  columns: (0.35fr, 1fr, 1fr, 0.8fr),
  inset: 5pt,
  [Step], [Thread A], [Thread B], [Shared `total`],
  [1], [read 7], [], [7],
  [2], [], [read 7], [7],
  [3], [compute 8], [], [7],
  [4], [], [compute 8], [7],
  [5], [write 8], [], [8],
  [6], [], [write 8], [*8*],
)

#v(0.25cm)
#grid(
  columns: (1fr, 1fr),
  gutter: 14pt,
  key-box([Race condition], [Outcome depends on uncontrolled timing/interleaving. The table illustrates one lost update.]),
  key-box([Data race], [Threads access one C object without synchronization and at least one writes: undefined behavior.], fill: usyd-light-grey),
)

== Mutexes

```c
#include <pthread.h>

static int x = 0;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

void *increase(void *arg) {
    (void)arg;

    pthread_mutex_lock(&lock);
    x = x + 1;
    pthread_mutex_unlock(&lock);

    return NULL;
}
```

// SPEAKER [04:00]
// ASK: What invariant does the lock protect? Which accesses must follow the protocol?
// CONTRAST: pthread_join observes completion; it does not repair an earlier race.
== Find the Invariant, Then Protect Its Critical Section

#grid(
  columns: (1fr, 1fr),
  gutter: 16pt,
  [
    #key-box([Before choosing a lock], [
      1. What state is shared?

      2. What invariant must remain true?

      3. Which reads and writes participate?

      4. Can ownership remove the sharing?
    ])
  ],
  code-text[
```c
int64_t local = compute(task);

pthread_mutex_lock(&total_lock);
shared_total += local;   // locked
pthread_mutex_unlock(&total_lock);
```
  ],
)

#v(0.22cm)
#rule([Critical section = the complete reads, decisions, and writes that preserve a shared invariant. Every conflicting access follows one mutex protocol; `join()` is only completion.])

== One Diagram to Remember

#grid(
  columns: (0.6fr, 1.4fr),
  gutter: 14pt,
  [
    #figure(
      image("img/mutexes.png")
    )
  ],
  [
    The thing being locked is the storage cage, not the shared resource. 
    
    Multiple resources (`a` and `b`) could be protected by one lock.

    One person can be treated as one thread. Only one thread can access the shared resource at a time: the one that holds the key.

    One lock is like one door. It only restricts the threads that use that access door (`M1`). If other threads use another door (`M2`), they can interfere at any time.
    
    Only the thread that locked the door can unlock it (1 key for 1 door).
    
    If a thread does not use a lock at all (by helicopter), it always has access to the shared resource.
  ],
)

= Deadlocks

== How A Simple Deadlock Happens?

```c
pthread_mutex_t M1;
pthread_mutex_t M2;
```

#grid(
  columns: (1fr, 1fr),
  gutter: 12pt,
  [
    Thread 1 locks them in this order:

    ```c
    pthread_mutex_lock(&M1);
    pthread_mutex_lock(&M2);
    
    /* do work */
    
    pthread_mutex_unlock(&M2);
    pthread_mutex_unlock(&M1);
    ```
  ],
  [
    Thread 2 locks them in the opposite order:
    
    ```c
    pthread_mutex_lock(&M2);
    pthread_mutex_lock(&M1);
    
    /* do work */
    
    pthread_mutex_unlock(&M1);
    pthread_mutex_unlock(&M2);
    ```
  ]
)

#pagebreak()

The dangerous part is the inconsistent lock acquisition order:

```
T1: M1 then M2
T2: M2 then M1

T1 locks M1
T2 locks M2
T1 tries to lock M2, but T2 has it
T2 tries to lock M1, but T1 has it

T1 holds M1 and waits for M2
T2 holds M2 and waits for M1

Neither thread can continue. T1 cannot unlock M1 because it is blocked waiting for M2. T2 cannot unlock M2 because it is blocked waiting for M1.
```

// SPEAKER [03:00]
// ASK: Students must provide four scheduler decisions, not just say "lock order".
// HOLD the classification until the next slide.
== Can These Two Lock Sequences Trap Each Other?

#align(center)[#text(fill: usyd-charcoal)[Pseudocode using `lock` / `unlock` shorthand for pthread mutex operations.]]
#v(0.08cm)
#grid(
  columns: (1fr, 1fr),
  gutter: 16pt,
  code-text[
```c
void catalogue_asset(void) {
    lock(&metadata);
    lock(&storage);
    update_catalogue();
    unlock(&storage);
    unlock(&metadata);
}
```
  ],
  code-text[
```c
void relocate_asset(void) {
    lock(&storage);
    lock(&metadata);
    move_asset();
    unlock(&metadata);
    unlock(&storage);
}
```
  ],
)

#v(0.25cm)
#question([Give one exact interleaving in which neither thread reaches `unlock`.])

// SPEAKER [04:00]
// REVEAL: Follow the four legal steps. Point to each unreachable unlock.
// DISTINGUISH: Blocking on one mutex is contention until the dependency closes.
== Four Legal Steps are Enough to Deadlock

#table(
  columns: (0.35fr, 1.45fr, 1fr, 1fr),
  inset: 5pt,
  [Step], [Action], [Tcat holds / waits], [Trel holds / waits],
  [1], [Tcat locks `metadata`], [`metadata` / none], [none / none],
  [2], [Trel locks `storage`], [`metadata` / none], [`storage` / none],
  [3], [Tcat requests `storage`], [`metadata` / `storage`], [`storage` / none],
  [4], [Trel requests `metadata`], [`metadata` / `storage`], [`storage` / `metadata`],
)

#v(0.35cm)
#question([Can either owner reach the release that the other needs?])

#v(0.2cm)
#align(center)[#bad([No: this is a closed set of blocked owners.])]

// SPEAKER [04:00]
// DRAW: Define arrows as waiter -> owner. Then map each Coffman condition to evidence.
// ASK: Would one directed edge alone prove deadlock? Expected: no.
== The Wait-For Cycle Makes the Dependency Explicit

#grid(
  columns: (1fr, 1fr),
  gutter: 16pt,
  [
    #node([Tcat\ holds `metadata`], fill: usyd-light-grey)
    #align(center)[#text(size: 18pt, weight: "bold", fill: usyd-ochre)[↓ waits for `storage`]]
    #node([Trel\ holds `storage`])
    #align(center)[#text(size: 18pt, weight: "bold", fill: usyd-ochre)[↑ waits for `metadata`]]
    #align(center)[*Closed directed cycle*]
  ],
  [
    #table(
      columns: (1.1fr, 1.8fr),
      [Coffman condition], [Evidence here],
      [Mutual exclusion], [each mutex has one owner],
      [Hold and wait], [each thread holds one and requests one],
      [No preemption], [a mutex is released by its owner],
      [Circular wait], [Tcat waits for Trel; Trel waits for Tcat],
    )
  ],
)

== The Four Conditions For Deadlock

Break anyone of them could prevent the deadlock.
```
1. Mutual exclusion
   At least one resource can only be held by one thread at a time.
   A mutex is exactly this kind of resource.

2. Hold and wait
   A thread is holding one resource while waiting for another.

3. No preemption
   A lock cannot be forcibly taken from a thread.
   The thread that owns the lock must voluntarily unlock it.

4. Circular wait
   A cycle of waiting exists.
   For example, T1 waits for T2, and T2 waits for T1.
```

// SPEAKER [03:00]
// REVEAL: Both functions acquire ranks in increasing order.
// ASK: Which Coffman condition is deliberately broken? Expected: circular wait.
// PROOF: Ranks would have to strictly increase around a cycle and return higher than themselves.
== A Global Lock Order Makes Circular Wait Impossible

#grid(
  columns: (1fr, 1fr),
  gutter: 16pt,
  [
    #key-box([One published order], [
      `metadata_lock` (rank 1)

      #align(center)[#text(size: 18pt, weight: "bold", fill: usyd-ochre)[↓ acquire a higher rank]]

      `storage_lock` (rank 2)

      Every path strictly increases rank.
    ])
  ],
  [
    #key-box([Why the repair works], [
      Assume a wait cycle exists.

      Every edge goes from a held lower rank to a requested higher rank.

      Ranks must strictly increase around the cycle, yet return to the start: impossible.
    ], fill: usyd-light-grey)
  ],
)

#v(0.2cm)
#align(center)[*Race:* unsafe access #h(0.4cm) *Contention:* owner can progress #h(0.4cm) *Deadlock:* closed blocked dependency]

= Condition Variables and Semaphores

== Semaphores: WcDonald's
For detailed explanations, please refer to #link("https://github.com/ninn-kou/COMP2017-Tutorials/blob/main/Week%2012/Week_12_Tutorial_A.md#a2-semaphores").
#grid(
  columns: (1fr, 1fr),
  gutter: 6pt,
  image("img/semaphore_busy_wait_1.png", width: 100%),
  image("img/semaphore_busy_wait_2.png", width: 100%),
  image("img/semaphore_busy_wait_3.png", width: 100%),
  image("img/semaphore_busy_wait_4.png", width: 100%)
)

#grid(
  columns: (1fr, 1fr, 1fr),
  gutter: 6pt,
  image("img/semaphore_counting_1.png", width: 100%),
  image("img/semaphore_counting_2.png", width: 100%),
  image("img/semaphore_counting_3.png", width: 100%),
  image("img/semaphore_counting_4.png", width: 100%),
  image("img/semaphore_counting_5.png", width: 100%),
  image("img/semaphore_counting_6.png", width: 100%)
)


// SPEAKER [04:00]
// TRACE: cond_wait atomically releases the mutex and later reacquires it.
// ASK: Why while rather than if? Expected: spurious wakeup or predicate changed again.
== A Condition Variable Waits for a Predicate

#grid(
  columns: (1fr, 1fr),
  gutter: 14pt,
  code-text[
```c
pthread_mutex_lock(&m);
while (queue_empty())
    pthread_cond_wait(&not_empty,
                      &m);

item = queue_remove();
pthread_mutex_unlock(&m);
```
  ],
  [
    #stack(spacing: 7pt,
      node([1. lock and test predicate], fill: usyd-light-grey),
      node([2. wait releases mutex atomically]),
      node([3. producer locks `m`, changes state, signals, unlocks], fill: usyd-light-grey),
      node([4. waiter reacquires and retests]),
    )
  ],
)

#v(0.2cm)
#align(center)[*Semaphore:* the count persists. #h(0.7cm) *Condition variable:* a notification is not stored state.]



// SPEAKER [04:00]
// RAPID FIRE: read-mostly configuration; four empty slots; empty work queue.
// ASK: What relationship must the program express in each scenario?
== Choose a Primitive by the Relationship You Need

#table(
  columns: (1.5fr, 1fr, 1.5fr),
  inset: 5pt,
  [Question], [Primitive], [Use when...],
  [Who owns one invariant?], [mutex], [one participant at a time enters the protocol],
  [Many readers or one writer?], [read-write lock], [reads dominate and the invariant tolerates concurrent readers],
  [How many units are available?], [semaphore], [permits, items, or slots must be counted],
  [Is a predicate true yet?], [condition variable + mutex], [a thread should sleep until protected state may have changed],
)

#v(0.2cm)
#tiny[#key-box([API memory jog], [
  `pthread_rwlock_rdlock`: concurrent readers; `wrlock`: exclusive writer. `sem_wait`: consume or block at zero; `sem_post`: add a permit.
])]

= Recursion and Exam Transfer

// SPEAKER [04:00]
// ASK: What proves the next call is smaller? Does recursion itself create threads?
// EXPECT: Strict progress toward base; no, parallelism must be explicit and bounded.
== Recursion Needs a Base Case and Strict Progress

#grid(
  columns: (1fr, 1fr),
  gutter: 16pt,
  [
    #stack(spacing: 6pt,
      node([`sum_to(3)` = `3 + sum_to(2)`]),
      node([`sum_to(2)` = `2 + sum_to(1)`], fill: usyd-light-grey),
      node([`sum_to(1)` = `1 + sum_to(0)`]),
      node([`sum_to(0)` = `0`  base case], fill: usyd-light-grey),
    )
    #align(center)[unwind: `0 -> 1 -> 3 -> 6`]
  ],
  [
    #key-box([Four Questions], [
      1. What is the base case?

      2. What measure strictly decreases?

      3. What subproblem is called?

      4. How are returned values combined?
    ])
    #v(0.25cm)
    #key-box([Parallel Recursion], [
      
      Independent branches + cutoff + bounded workers + join before combine.
    ], fill: usyd-light-grey)
  ],
)

== Recursions with Multi-Threads: W12 Tut B - Fibonacci Numbers - III

#link("https://github.com/ninn-kou/COMP2017-Tutorials/blob/main/Week%2012/Week_12_Tutorial_B.md#b4-exercise-fibonacci-numbers---iii")



// SPEAKER [03:00]
// RETRIEVAL: Cover the rightmost column and ask students to choose the mechanism.
// EMPHASISE: Every complete design accounts for state, data, completion, and blocking.
== Rebuild the Answer from the Obligation

#table(
  columns: (1.25fr, 1.35fr, 2.1fr),
  inset: 5pt,
  [Obligation], [Likely Mechanism], [One Sentence that Earns Clarity],
  [Create a worker], [`fork()` / `pthread_create()`], [state whether memory is separate or shared; pass stable task state],
  [Return a child result], [`pipe()` / shared mapping], [name the explicit process data path],
  [Observe completion], [`waitpid()` / `pthread_join()`], [reap or join the exact successfully created set],
  [Protect a live invariant], [mutex / rwlock / semaphore / condvar], [choose by the required synchronization relationship],
  [Repair deadlock], [global lock order], [state the order and prove the wait cycle impossible],
)

== Last...

These slides may be *updated dynamically* over the coming days, so please always check this page for the latest version.

Additionally, please note that our workshop does not cover all of the semester's content. For more detailed explanations, you can visit #link("https://github.com/ninn-kou/COMP2017-Tutorials").

#v(12pt)

*Thank you for your participation today. Good luck with your P2P exam!*

#align(right + bottom)[
  _Slides Version: 2.3_
]

// Sources used to design this deck:
// - Attached COMP2017 W7-W12 lecture materials and the approved revision notes.
// - https://github.com/ninn-kou/COMP2017-Tutorials
// - https://github.com/skriptum/diatypst/tree/0.9.3
